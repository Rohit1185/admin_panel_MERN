import './App.css';
import Task from './Component/Task';

function App() {
  return (
    <Task/>
  );
}

export default App;
