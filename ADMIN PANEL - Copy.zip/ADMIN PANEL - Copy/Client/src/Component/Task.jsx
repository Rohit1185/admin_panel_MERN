import axios from "axios";
import { useState, useEffect, useRef } from "react";

function Task() {
  const [dbTasks, setDbTasks] = useState([]);
  const [editingTask, setEditingTask] = useState(null); // To track the task being edited
  const nameRef = useRef("");
  const emailRef = useRef("");
  const passwordRef = useRef("");

  // Fetch all tasks on component load
  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await axios.get("http://localhost:8080/task");
      setDbTasks(response.data);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      setDbTasks([]);
    }
  };

  // Add a new task
  const addTask = async () => {
    const data = {
      name: nameRef.current.value,
      email: emailRef.current.value,
      password: passwordRef.current.value,
    };

    try {
      await axios.post("http://localhost:8080/task", data);
      fetchTasks(); // Refresh the task list
      nameRef.current.value = "";
      emailRef.current.value = "";
      passwordRef.current.value = "";
    } catch (error) {
      console.error("Error adding task:", error);
    }
  };

  // Delete a task
  const deleteTask = async (id) => {
    try {
      await axios.delete(`http://localhost:8080/task/${id}`);
      fetchTasks(); // Refresh the task list
    } catch (error) {
      console.error("Error deleting task:", error);
    }
  };

  // Update a task
  const updateTask = async (id) => {
    const updatedData = {
      name: nameRef.current.value || editingTask.name,
      email: emailRef.current.value || editingTask.email,
      password: passwordRef.current.value || editingTask.password,
    };

    try {
      await axios.put(`http://localhost:8080/task/${id}`, updatedData);
      fetchTasks(); // Refresh the task list
      setEditingTask(null); // Exit edit mode
      nameRef.current.value = "";
      emailRef.current.value = "";
      passwordRef.current.value = "";
    } catch (error) {
      console.error("Error updating task:", error);
    }
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial", backgroundColor: "#f0f8ff", minHeight: "100vh" }}>
      <h1 style={{ textAlign: "center", color: "#333", marginBottom: "30px" }}>Admin Panel</h1>

      <div
        style={{
          marginBottom: "20px",
          padding: "20px",
          backgroundColor: "#fff",
          borderRadius: "10px",
          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
        }}
      >
        <label style={{ marginRight: "10px", fontWeight: "bold" }}>Name:</label>
        <input
          type="text"
          ref={nameRef}
          style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ddd", marginRight: "20px" }}
        />
        <label style={{ marginRight: "10px", fontWeight: "bold" }}>Email:</label>
        <input
          type="email"
          ref={emailRef}
          style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ddd", marginRight: "20px" }}
        />
        <label style={{ marginRight: "10px", fontWeight: "bold" }}>Password:</label>
        <input
          type="password"
          ref={passwordRef}
          style={{ padding: "10px", borderRadius: "5px", border: "1px solid #ddd" }}
        />
        {editingTask ? (
          <button
            onClick={() => updateTask(editingTask._id)}
            style={{
              marginLeft: "20px",
              padding: "10px 20px",
              backgroundColor: "#4caf50",
              color: "white",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
            }}
          >
            Update Task
          </button>
        ) : (
          <button
            onClick={addTask}
            style={{
              marginLeft: "20px",
              padding: "10px 20px",
              backgroundColor: "#007bff",
              color: "white",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
            }}
          >
            Add
          </button>
        )}
      </div>

      <table style={{ width: "100%", borderCollapse: "collapse", backgroundColor: "#fff", borderRadius: "10px", overflow: "hidden", boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)" }}>
        <thead>
          <tr style={{ backgroundColor: "#007bff", color: "white" }}>
            <th style={{ padding: "15px", textAlign: "left" }}>Name</th>
            <th style={{ padding: "15px", textAlign: "left" }}>Email</th>
            <th style={{ padding: "15px", textAlign: "left" }}>Password</th>
            <th style={{ padding: "15px", textAlign: "left" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {Array.isArray(dbTasks) &&
            dbTasks.map((task) => (
              <tr
                key={task._id}
                style={{
                  borderBottom: "1px solid #ddd",
                  transition: "background-color 0.3s",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#f9f9f9")}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "white")}
              >
                <td style={{ padding: "15px" }}>{task.name}</td>
                <td style={{ padding: "15px" }}>{task.email}</td>
                <td style={{ padding: "15px" }}>{task.password}</td>
                <td style={{ padding: "15px" }}>
                  <button
                    onClick={() => setEditingTask(task)}
                    style={{
                      marginRight: "10px",
                      padding: "10px 15px",
                      backgroundColor: "#ffc107",
                      color: "white",
                      border: "none",
                      borderRadius: "5px",
                      cursor: "pointer",
                    }}
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => deleteTask(task._id)}
                    style={{
                      padding: "10px 15px",
                      backgroundColor: "#dc3545",
                      color: "white",
                      border: "none",
                      borderRadius: "5px",
                      cursor: "pointer",
                    }}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}

export default Task;