const taskModel = require("../Model/taskModel");

// Insert a new task
exports.insertOne = async (task) => {
  try {
    const newTask = new taskModel({
      name: task.name,
      email: task.email,
      password: task.password,
    });
    await newTask.save();
    return "Task successfully added";
  } catch (error) {
    console.error("Error adding task:", error);
    throw new Error("Failed to add task");
  }
};

// Get all tasks
exports.getAll = async () => {
  try {
    return await taskModel.find();
  } catch (error) {
    console.error("Error fetching tasks:", error);
    throw new Error("Failed to fetch tasks");
  }
};

// Delete a task by ID
exports.deleteOne = async (id) => {
  try {
    const result = await taskModel.findByIdAndDelete(id);
    return result ? "Task successfully deleted" : "Task not found";
  } catch (error) {
    console.error("Error deleting task:", error);
    throw new Error("Failed to delete task");
  }
};

// Update a task by ID
exports.updateOne = async (id, updatedData) => {
  try {
    const result = await taskModel.findByIdAndUpdate(id, updatedData, { new: true });
    return result ? "Task successfully updated" : "Task not found";
  } catch (error) {
    console.error("Error updating task:", error);
    throw new Error("Failed to update task");
  }
};
