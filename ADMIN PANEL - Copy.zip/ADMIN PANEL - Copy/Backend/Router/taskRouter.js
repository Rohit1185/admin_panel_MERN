const express = require("express");
const router = express.Router();
const taskController = require("../Controller/taskController");

// Fetch all tasks
router.get("/", async (req, res) => {
  try {
    const tasks = await taskController.getAll();
    res.status(200).json(tasks);
  } catch (error) {
    res.status(500).send("Error fetching tasks");
  }
});

// Add a new task
router.post("/", async (req, res) => {
  try {
    const result = await taskController.insertOne(req.body);
    res.status(201).send(result);
  } catch (error) {
    res.status(500).send("Error adding task");
  }
});

// Delete a task by ID
router.delete("/:id", async (req, res) => {
  try {
    const result = await taskController.deleteOne(req.params.id);
    res.status(200).send(result);
  } catch (error) {
    res.status(500).send("Error deleting task");
  }
});

// Update a task by ID
router.put("/:id", async (req, res) => {
  try {
    const result = await taskController.updateOne(req.params.id, req.body);
    res.status(200).send(result);
  } catch (error) {
    res.status(500).send("Error updating task");
  }
});

module.exports = router;
