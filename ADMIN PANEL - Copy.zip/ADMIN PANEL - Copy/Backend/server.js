const express = require("express");
const app = express();
let dbconfig = require("./Config/config");
let taskrouter = require("./Router/taskRouter");
let cors = require("cors");


app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended:true}));

app.use("/task",taskrouter);

app.get("/",(req,res)=>{
    res.send("user /task for tasks");
})

app.listen(8080,()=>{console.log("Server is running")});